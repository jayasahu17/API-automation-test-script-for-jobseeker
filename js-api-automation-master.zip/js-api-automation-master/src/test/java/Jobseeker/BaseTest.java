package Jobseeker;

import org.testng.annotations.Test;


public class BaseTest {

    public static String BASE_URL="http://10.120.11.137:8085";
}
