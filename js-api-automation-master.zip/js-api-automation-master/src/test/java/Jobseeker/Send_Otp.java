package Jobseeker;

import PojoJobseeker.PojoSendOtp.Request;
import PojoJobseeker.PojoSendOtp.Response_Send_Otp;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static Jobseeker.BaseTest.BASE_URL;


public class Send_Otp {

    @Test
    public static void send_otp() throws JsonProcessingException {
        RestAssured.baseURI = BASE_URL;
        Request request = new Request();
        request.setPhone("8839470347");

        // Send POST request and receive response
        Response response = RestAssured.given()
                .header("Content-Type", "application/json;charset=UTF-8")
                .body(request)
                .when().log().all()
                .post("/auth/jobseeker/v2/send_otp")
                .then().log().all()
                .extract().response();

        //Deserialization

        Response_Send_Otp response_send_otp = response.as(Response_Send_Otp.class);
        System.out.println(response_send_otp.isStatus());

        //Assertion
        Assert.assertEquals(response.statusCode(),200,"check for status code");





    }

}