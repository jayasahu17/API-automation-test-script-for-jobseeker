package Jobseeker;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static Jobseeker.BaseTest.BASE_URL;
import static org.testng.Assert.assertEquals;

public class CategorySequence {

    @Test
    public static void category_sequence(){
        RestAssured.baseURI = BASE_URL;;

        // Request header

        String accept = "application/json, text/plain, */*";
        String acceptlanguage = "en-US,en;q=0.9";
        String authorization = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXlsb2FkIjp7InVzZXJfaWQiOjE3NTM4MDg0MDgsInN0YXR1cyI6InZlcmlmaWVkIn0sImlhdCI6MTcxMTE4OTgzOSwiZXhwIjoxNzQyNzI1ODM5fQ.GJ1rxnX1Spk81ngnuB0yXZwSi8H-JZNIhuKkSGV8nao";
        String cacheControl = "no-cache";
        String connection = "keep-alive";
        String origin = "https://stagingjobhai.infoedge.com";
        String pragma = "no-cache";
        String userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36";
        String deviceId = "7cfc8e00-d75f-4cd7-a24c-853e53f3ae5d";
        String language = "en";
        String source = "WEB";
        String transactionId = "JS-WEB-3d6fdcb2-fdf8-4f61-808b-940228d3efc5";

        // Sending the request and capturing the response

        Response response = RestAssured.given()
                .header("Accept", accept)
                .header("Accept-Language", acceptlanguage)
                .header("Authorization", authorization)
                .header("Cache-Control", cacheControl)
                .header("Connection", connection)
                .header("Origin", origin)
                .header("Pragma", pragma)
                .header("User-Agent", userAgent)
                .header("device-id", deviceId)
                .header("language", language)
                .header("source", source)
                .header("x-transaction-id", transactionId)
                .when().log().all()
                .get("/user/categories-sequence")
                .then().log().all()
                .extract().response();



        //getting status code
        int StatusCode = response.getStatusCode();
        System.out.println("response getStatusCode "+ StatusCode);

        // getting response body
        String ResponseBody = response.getBody().asString();
        System.out.println("Response body: " + response.getBody().asString());


        //Assertion

        assertEquals(StatusCode, 200, "Expected status code to be 200");
    }
}










