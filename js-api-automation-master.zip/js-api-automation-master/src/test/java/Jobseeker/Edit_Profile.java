package Jobseeker;

import PojoJobseeker.PojoEditprofile.RequestBASIC;
import PojoJobseeker.PojoEditprofile.ResponseEditProfile;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.commons.codec.language.bm.Languages;
import org.testng.annotations.Test;

import static Jobseeker.BaseTest.BASE_URL;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class Edit_Profile {

    @Test
    public static void EditProfile() {

        RestAssured.baseURI = BASE_URL;
        RequestBASIC requestBASIC = new RequestBASIC();
        requestBASIC.setAddReferCount(false);
        requestBASIC.setAge(22);
        requestBASIC.setAddress("Sector 62 Noida, Noida");
        requestBASIC.setEmail("");
        requestBASIC.setGender("female");
        requestBASIC.setCity_id("7_LOCATION");
        requestBASIC.setIs_sms_enabled(true);
        requestBASIC.setCurrent_salary(20000);
        requestBASIC.setIs_whatsapp_enabled_for_recruiter(true);
        requestBASIC.setIs_whatsapp_permission_allowed(true);
        requestBASIC.setLocality_id("90_LOCALITY");
        requestBASIC.setQualification_id(5);
        requestBASIC.setSchool_medium("english");
        requestBASIC.setName("JAYA SAHU");
        requestBASIC.setSchool_subject("Hindi");


        Response response = RestAssured.given()
                .header("device-id", "2b79ea7d-d3b8-4916-a137-d10646571af1")
                .header("source", "APP")
                .header("language", "en")
                .header("versionCode", "210030891")
                .header("X-TRANSACTION-ID", "JsApp-66b901d5-7d33-46d5-9718-6ed0b0c41cdb")
                .header("User-Agent", "JsApp/210030891")
                .header("Session-Id", "460533ef-262c-44ca-b9c5-90db77f05edf")
                .header("Referer", "https://www.jobhai.com")
                .header("Cookie", "source=JsApp/210030891")
                .header("Accept", "*/*")
                .header("Accept-Language", "*")
                .header("Accept-Encoding", "*")
                .header("Connection", "close")
                .header("authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXlsb2FkIjp7InVzZXJfaWQiOjE3NTM4MDg0MDksInN0YXR1cyI6InZlcmlmaWVkIn0sImlhdCI6MTcxMTQzNTM3NywiZXhwIjoxNzQyOTcxMzc3fQ.0bwGSs1qrG7wH-tY7hZcX3aRG5Z8lbarXA09l7x1cdI")
                .contentType("application/json")
                .when().log().all()
                .post("/user/v4/edit-profile")
                .then().log().all()
                .extract().response();


            //Deserialization

        ResponseEditProfile responseEditProfile = response.as(ResponseEditProfile.class);
        System.out.println(responseEditProfile.isStatus());


        //Assertion

        assertEquals(response.getStatusCode(), 200);



    }

}








