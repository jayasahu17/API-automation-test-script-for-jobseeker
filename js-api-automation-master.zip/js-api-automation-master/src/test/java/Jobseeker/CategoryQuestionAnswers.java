package Jobseeker;

import PojoJobseeker.PojoCategoryQuestionAnswer.RequestCategoryQuestionAnswers;
import PojoJobseeker.PojoCategoryQuestionAnswer.ResponseCategoryQuestionAnswer;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static Jobseeker.BaseTest.BASE_URL;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class CategoryQuestionAnswers {

    @Test
    public static void category_question_answer(){
        RestAssured.baseURI = BASE_URL;
        RequestCategoryQuestionAnswers requestCategoryQuestionAnswers = new RequestCategoryQuestionAnswers();
        requestCategoryQuestionAnswers.setCategory_id("28");


        Response response = RestAssured.given()
                .header("content-type","application/json;charset=UTF-8")
                .header("Authorization","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXlsb2FkIjp7InVzZXJfaWQiOjE3NTM4MDg0MDgsInN0YXR1cyI6InZlcmlmaWVkIn0sImlhdCI6MTcxMTE4OTgzOSwiZXhwIjoxNzQyNzI1ODM5fQ.GJ1rxnX1Spk81ngnuB0yXZwSi8H-JZNIhuKkSGV8nao")
                .header("device-id","7cfc8e00-d75f-4cd7-a24c-853e53f3ae5d")
                .header("source", "WEB")
                .header("device-source", "DESKTOP")
                .body(requestCategoryQuestionAnswers)
                .when().log().all()
                .post("/user/category-question-answers")
                .then().log().all()
                .extract().response();

        //Deserialization


        ResponseCategoryQuestionAnswer ressponseBody = response.as(ResponseCategoryQuestionAnswer.class);

        response.prettyPrint();




        // Assertions
        assertEquals(response.getStatusCode(), 200);
        assertTrue(ressponseBody.isStatus());



    }

}
