package Jobseeker;

import PojoJobseeker.PojoGetJobs.RequestGetJobs;
import PojoJobseeker.PojoGetJobs.ResponseGetJobs;
import PojoJobseeker.PojoJDCall.ResponseJDCall;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static Jobseeker.BaseTest.BASE_URL;
import static java.util.Optional.empty;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;

public class GetJobs {
    @Test
    public static void Get_Jobs() {
        RestAssured.baseURI = BASE_URL;
        RequestGetJobs requestGetJobs = new RequestGetJobs();
        requestGetJobs.setPage(1);
        requestGetJobs.setSize(20);
        requestGetJobs.setJob_type("near_by");
        requestGetJobs.setFilter(null);
        requestGetJobs.setContextual_filters(null);
        requestGetJobs.setDistance_filters(null);
        requestGetJobs.setBus_metro_filters(null);
        requestGetJobs.setCategory(null);
        requestGetJobs.setLocality("90_LOCALITY");
        requestGetJobs.setCity(null);
        requestGetJobs.setTitle_filters(null);
        requestGetJobs.setPassed_filters(null);
        requestGetJobs.setKeyword(null);
        requestGetJobs.setTopMatchJobsOnly(false);

        //sending request
        Response response = RestAssured.given()
                .header("device-id", "67bbce91-81fa-4629-b5fb-07da28d5cfc6")
                .header("source", "APP")
                .header("language", "en")
                .header("versionCode", "210030891")
                .header("X-TRANSACTION-ID", "JsApp-fb408747-4b02-4be9-97b3-8f86f2ef60e4")
                .header("User-Agent", "JsApp/210030891")
                .header("Session-Id", "0785bf6f-76bb-49c3-bbc5-8ffb3069bdb2")
                .header("Referer", "https://www.jobhai.com")
                .header("authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXlsb2FkIjp7InVzZXJfaWQiOjE3NTM4MDg0MDksInN0YXR1cyI6InZlcmlmaWVkIn0sImlhdCI6MTcxMTM4NTYxMCwiZXhwIjoxNzQyOTIxNjEwfQ.EK9Bsvk5G2Prq8pYl14VqxBi553rN8kFyhfQ51EgmHo")
                .header("Accept", "*/*")
                .header("Accept-Encoding", "*")
                .header("Accept-Language", "*")
                .header("Connection", "close")
                .header("Content-Type", "application/json;charset=UTF-8")
                .body(requestGetJobs)
                .when().log().all()
                .post("/jobs/v4/get-jobs")
                .then().log().all()
                .extract().response();


        //Deserialization

        ResponseJDCall responseJDCall = response.as(ResponseJDCall.class);
        System.out.println(responseJDCall.isStatus());


        //Assertion

        Assert.assertEquals(response.statusCode(), 200, "check for status code");


    }

}