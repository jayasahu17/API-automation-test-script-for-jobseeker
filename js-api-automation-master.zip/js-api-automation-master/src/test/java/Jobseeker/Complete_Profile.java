package Jobseeker;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static Jobseeker.BaseTest.BASE_URL;
import static org.testng.Assert.assertEquals;

public class Complete_Profile {

    @Test

    public  static  void CompleteProfile(){

        RestAssured.baseURI = BASE_URL;

        // Sending the request and capturing the response

      Response response = RestAssured.given()
              .header("device-id","2b79ea7d-d3b8-4916-a137-d10646571af1")
              .header("source","APP")
              .header("language","en")
              .header("versionCode","210030891")
              .header("X-TRANSACTION-ID","JsApp-b4a5c640-0a18-4109-88e4-2c70198c13e3")
              .header("User-Agent","JsApp/210030891")
              .header("Session-Id","460533ef-262c-44ca-b9c5-90db77f05edf")
              .header("Referer","https://www.jobhai.com")
              .header("Cookie","source=JsApp/210030891")
              .header("Accept","*/*")
              .header("Accept-Language","*")
              .header("Accept-Encoding","*")
              .header("Connection","close")
              .header("authorization","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXlsb2FkIjp7InVzZXJfaWQiOjE3NTM4MDg0MDksInN0YXR1cyI6InZlcmlmaWVkIn0sImlhdCI6MTcxMTQzNTM3NywiZXhwIjoxNzQyOTcxMzc3fQ.0bwGSs1qrG7wH-tY7hZcX3aRG5Z8lbarXA09l7x1cdI")
              .when().log().all()
              .get("/user/v4/complete-profile")
              .then().log().all()
              .extract().response();



              //getting Status Code

        int StatusCode = response.getStatusCode();
        System.out.println("response getStatusCode"+StatusCode);


        //getting responseBody

        String ResponseBody = response.getBody().asString();
        System.out.println("response getBody"+ResponseBody);


        //Assertion

        assertEquals(StatusCode, 200, "Expected status code to be 200");




    }



}
