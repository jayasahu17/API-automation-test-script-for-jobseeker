package Jobseeker;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.IOException;

import static Jobseeker.BaseTest.BASE_URL;

public class Dashboard_Jobs {

    @Test
    public  static  void DashboardJobs() {
        RestAssured.baseURI = BASE_URL;

        //getting response

        Response response = RestAssured.given()
                .header("device-id", "f4ace45f-9eb0-4ea4-abbf-5999279d6245")
                .header("source", "APP")
                .header("language", "en")
                .header("versionCode", "210030891")
                .header("X-TRANSACTION-ID", "JsApp-0390cd80-f8e3-4fe8-8449-f91275d46725")
                .header("User-Agent", "JsApp/210030891")
                .header("Session-Id", "6c761b2b-018f-497c-a2b5-d2da3a06338c")
                .header("Referer", "https://www.jobhai.com")
                .header("Cookie", "source=JsApp/210030891")
                .header("Accept", "*/*")
                .header("Accept-Language", "*")
                .header("Accept-Encoding", "*")
                .header("Connection", "close")
                .header("authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXlsb2FkIjp7InVzZXJfaWQiOjE3NTM4MDg0MDksInN0YXR1cyI6InZlcmlmaWVkIn0sImlhdCI6MTcxMTQ0MjAyMiwiZXhwIjoxNzQyOTc4MDIyfQ.AklmXOSI8Is2OwXoCesh6vE8z5B5LoR-_489KGow6qw")
                .when().log().all()
                .get("/user/dashboard-jobs")
                .then().log().all()
                .extract().response();

        // getting status code

        int StatusCode = response.getStatusCode();
        System.out.println("response.getStatusCode"+StatusCode);

        //getting responseBody text

        String ResponseBody = response.getBody().asString();
        System.out.println("Response body: " + response.getBody().asString());


    }
}
