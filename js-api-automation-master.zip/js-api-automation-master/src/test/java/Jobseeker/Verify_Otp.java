package Jobseeker;

import PojoJobseeker.PojoVerifyOtp.RequestVerifyOtp;
import PojoJobseeker.PojoVerifyOtp.ResponseVerifyOtp;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static Jobseeker.BaseTest.BASE_URL;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class Verify_Otp {

    @Test
    public static void verify_otp() {
        RestAssured.baseURI = BASE_URL;

        RequestVerifyOtp requestVerifyOtp = new RequestVerifyOtp();
        requestVerifyOtp.setPhone("9098793120");
        requestVerifyOtp.setOtp("1836");
        requestVerifyOtp.setLast_visited_page("login");

        Response response = RestAssured.given()
                .header("Content-Type", "application/json;charset=UTF-8")
                .header("source", "WEB")  // Add the source header
                .header("device-id", "619bb2a7-60ac-41e7-a249-bad215b9f9fe")  // Add the device-id header
                .header("device-source", "Desktop")
                .body(requestVerifyOtp)
                .when().log().all()
                .post("/auth/jobseeker/v2/verify_otp")
                .then().log().all()
                .extract().response();

        //Deserialization

        ResponseVerifyOtp responseVerifyOtp = response.as(ResponseVerifyOtp.class);



        //Assertion

        Assert.assertEquals(response.statusCode(),200,"check for status code");







    }

}