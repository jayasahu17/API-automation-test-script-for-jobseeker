package Jobseeker;

import PojoJobseeker.PojoJDCall.RequestJDCall;
import PojoJobseeker.PojoJDCall.ResponseJDCall;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static Jobseeker.BaseTest.BASE_URL;
import static io.restassured.RestAssured.given;

public class JD_CALL {

    @Test
    public static void JDCall() {
        // Set base URI
        RestAssured.baseURI = BASE_URL;

        // Create request object
        RequestJDCall requestJDCall = new RequestJDCall();
        requestJDCall.setJob_id(245695);

        // Send POST request and get response
        Response response = given()
                .header("device-id","47d084d4-123c-46d3-a5f5-72330e9ee41b")
                .header("Content-Type","application/json;charset=UTF-8")
                .header("source","APP")
                .header("language","en")
                .header("versionCode","210030893")
                .header("X-TRANSACTION-ID","JsApp-0402ac3a-2f57-417b-a50b-002a2505f3f5")
                .header("User-Agent","JsApp/210030893")
                .header("Session-Id","8fb57a9d-3472-4e8f-9ed2-45b94bbba10d")
                .header("Referer","https://www.jobhai.com")
                .header("Cookie","source=JsApp/210030893")
                .header("Accept","*/*")
                .header("Accept-Language","*")
                .header("Accept-Encoding","*")
                .header("Connection","close")
                .body(requestJDCall)
                .header("authorization","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXlsb2FkIjp7InVzZXJfaWQiOjE3NTM4MDg0NTQsInN0YXR1cyI6InZlcmlmaWVkIn0sImlhdCI6MTcxMjY2NDEwMSwiZXhwIjoxNzQ0MjAwMTAxfQ.wKMOuM9C94E1PYDD0tZFIMsem5HGWRxrDXfYizrJo2Y")
                .when().log().all()
                .post("/jobs/v4/call")
                .then().log().all()
                .extract().response();



        // Deserialization
        ResponseJDCall responseJDCall= response.as(ResponseJDCall.class);
        System.out.println(responseJDCall.isStatus());

        //Assertion

        Assert.assertEquals(response.getStatusCode(), 200, "Expected HTTP status code 200");

        // Assert response body
        Assert.assertTrue(responseJDCall.isStatus(), "Expected status to be true");



    }
}