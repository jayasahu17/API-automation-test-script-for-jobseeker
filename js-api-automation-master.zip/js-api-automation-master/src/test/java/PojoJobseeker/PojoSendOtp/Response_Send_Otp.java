package PojoJobseeker.PojoSendOtp;

import io.restassured.response.ResponseBody;

import java.util.Map;


public class Response_Send_Otp {

    private boolean status;

    private Map<String, Object> data;
    ;
    private String message;
    private int code;

    public boolean isStatus() {
        return status;
    }


    public Map<String, Object> getData(ResponseBody body) {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public String getMessage(ResponseBody body) {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode(int statusCode) {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public double getMessage() {


        return 0;
    }
}



