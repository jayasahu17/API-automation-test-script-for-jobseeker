package PojoJobseeker.PojoVerifyOtp;

import java.util.Map;

public class ResponseVerifyOtp {


    private boolean status;
    private Data data;
    private String message;
    private int code;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

// Inner data

    public static class Data {
        public String getFirst_name() {
            return first_name;
        }

        public void setFirst_name(String first_name) {
            this.first_name = first_name;
        }

        public String getLast_name() {
            return last_name;
        }

        public void setLast_name(String last_name) {
            this.last_name = last_name;
        }

        public String getUser_status() {
            return user_status;
        }

        public void setUser_status(String user_status) {
            this.user_status = user_status;
        }

        public boolean isIs_soft_profile_completed() {
            return is_soft_profile_completed;
        }

        public void setIs_soft_profile_completed(boolean is_soft_profile_completed) {
            this.is_soft_profile_completed = is_soft_profile_completed;
        }

        public boolean isIs_other_city_selected() {
            return is_other_city_selected;
        }

        public void setIs_other_city_selected(boolean is_other_city_selected) {
            this.is_other_city_selected = is_other_city_selected;
        }

        public boolean isIs_fresher() {
            return is_fresher;
        }

        public void setIs_fresher(boolean is_fresher) {
            this.is_fresher = is_fresher;
        }

        public Object getOther_city() {
            return other_city;
        }

        public void setOther_city(Object other_city) {
            this.other_city = other_city;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public int getCurrent_salary() {
            return current_salary;
        }

        public void setCurrent_salary(int current_salary) {
            this.current_salary = current_salary;
        }

        public int getQualification_id() {
            return qualification_id;
        }

        public void setQualification_id(int qualification_id) {
            this.qualification_id = qualification_id;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public boolean isIs_returning_user() {
            return is_returning_user;
        }

        public void setIs_returning_user(boolean is_returning_user) {
            this.is_returning_user = is_returning_user;
        }

        public int getUser_id() {
            return user_id;
        }

        public void setUser_id(int user_id) {
            this.user_id = user_id;
        }

        public String getLandingScreen() {
            return landingScreen;
        }

        public void setLandingScreen(String landingScreen) {
            this.landingScreen = landingScreen;
        }

        public String getM_landing_screen() {
            return m_landing_screen;
        }

        public void setM_landing_screen(String m_landing_screen) {
            this.m_landing_screen = m_landing_screen;
        }

        public boolean isShow_field_qualification() {
            return show_field_qualification;
        }

        public void setShow_field_qualification(boolean show_field_qualification) {
            this.show_field_qualification = show_field_qualification;
        }

        public boolean isShow_field_joining_info() {
            return show_field_joining_info;
        }

        public void setShow_field_joining_info(boolean show_field_joining_info) {
            this.show_field_joining_info = show_field_joining_info;
        }

        public String getRegistrationFlow() {
            return RegistrationFlow;
        }

        public void setRegistrationFlow(String registrationFlow) {
            RegistrationFlow = registrationFlow;
        }

        private String first_name;
        private String last_name;
        private String user_status;
        private boolean is_soft_profile_completed;
        private boolean is_other_city_selected;
        private boolean is_fresher;
        private Object other_city;
        private String gender;
        private int current_salary;
        private int qualification_id;
        private String token;
        private boolean is_returning_user;
        private int user_id;
        private String landingScreen;
        private String m_landing_screen;
        private boolean show_field_qualification;
        private boolean show_field_joining_info;
        private String RegistrationFlow;

    }

}







