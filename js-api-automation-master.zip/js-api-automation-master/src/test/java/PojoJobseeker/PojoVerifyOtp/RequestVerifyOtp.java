package PojoJobseeker.PojoVerifyOtp;

//import com.fasterxml.jackson.annotation.JsonProperty;

public class RequestVerifyOtp {

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public void setLast_visited_page(String last_visited_page) {
        this.last_visited_page = last_visited_page;
    }

//    @JsonProperty
    public String getPhone() {
        return phone;
    }

//    @JsonProperty
    public String getOtp() {
        return otp;
    }

//    @JsonProperty
    public String getLast_visited_page() {
        return last_visited_page;
    }

    String phone;
    String otp;
    String last_visited_page;

}
