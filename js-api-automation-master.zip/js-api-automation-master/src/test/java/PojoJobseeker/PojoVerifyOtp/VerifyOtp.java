package PojoJobseeker.PojoVerifyOtp;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class VerifyOtp {

    @Test
    public static void verify_otp() {
        RestAssured.baseURI = "http://10.120.11.137:8085";
        RequestVerifyOtp requestVerifyOtp = new RequestVerifyOtp();
        requestVerifyOtp.setPhone("9098793120");
        requestVerifyOtp.setOtp("1836");
        requestVerifyOtp.setLast_visited_page("login");

        Response response = RestAssured.given()
                .header("Content-Type", "application/json;charset=UTF-8")
                .header("source", "WEB")  // Add the source header
                .header("device-id", "619bb2a7-60ac-41e7-a249-bad215b9f9fe")  // Add the device-id header
                .header("device-source", "Desktop")
                .body(requestVerifyOtp)
                .when()
                .post("/auth/jobseeker/v2/verify_otp")
                .then()
                .extract().response();

        // covert

        ObjectMapper objectMapper = new ObjectMapper();

        ObjectWriter ResponseVerifyOtp = objectMapper.writerWithDefaultPrettyPrinter();
        System.out.println(ResponseVerifyOtp);


        //response


        response.prettyPrint();


        Assert.assertEquals(response.statusCode(),200,"check for status code");


    }
}