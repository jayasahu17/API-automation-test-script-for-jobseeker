package PojoJobseeker.PojoApply;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import static Jobseeker.BaseTest.BASE_URL;

public class JDApply {

    @Test
    public static void JobApply(){
        RestAssured.baseURI = BASE_URL;

        RequestApply requestApply = new RequestApply();
        requestApply.setJob_id(246651);


        Response response = RestAssured.given()
                .headers("device-id", "47d084d4-123c-46d3-a5f5-72330e9ee41b")
                .header("source", "APP")
                .header("language", "en")
                .header("versionCode", "210030893")
                .header("X-TRANSACTION-ID", "JsApp-198369b7-81e3-4ca8-ad8d-b2a59a8f3d1c")
                .header("Session-Id", "8fb57a9d-3472-4e8f-9ed2-45b94bbba10d")
                .header("Cookie", "source=JsApp/210030893")
                .header("Accept", "*/*")
                .header("Connection", "close")
                .header("authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXlsb2FkIjp7InVzZXJfaWQiOjE3NTM4MDg0NTQsInN0YXR1cyI6InZlcmlmaWVkIn0sImlhdCI6MTcxMjY2NDEwMSwiZXhwIjoxNzQ0MjAwMTAxfQ.wKMOuM9C94E1PYDD0tZFIMsem5HGWRxrDXfYizrJo2Y")
                .formParam("job_id", "246650")
                .formParam("is_special_apply", "false")
                .formParam("is_fatafat_action", "false")
                .formParam("is_fatafat_top_job", "false")
                .when().log().all()
                .post("/jobs/v4/apply")
                .then().log().all()
                .extract().response();

        //Deserialization

        System.out.println(response.toString());
        ResponseApply responseApply = response.as(ResponseApply.class);
        System.out.println(responseApply.isStatus());



















    }







}
