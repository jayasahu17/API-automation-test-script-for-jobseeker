package PojoJobseeker.PojoApply;

public class RequestApply {

    public int getJob_id() {
        return job_id;
    }

    public void setJob_id(int job_id) {
        this.job_id = job_id;
    }

    public boolean isIs_special_apply() {
        return is_special_apply;
    }

    public void setIs_special_apply(boolean is_special_apply) {
        this.is_special_apply = is_special_apply;
    }

    public boolean isIs_fatafat_action() {
        return is_fatafat_action;
    }

    public void setIs_fatafat_action(boolean is_fatafat_action) {
        this.is_fatafat_action = is_fatafat_action;
    }

    public boolean isIs_fatafat_top_job() {
        return is_fatafat_top_job;
    }

    public void setIs_fatafat_top_job(boolean is_fatafat_top_job) {
        this.is_fatafat_top_job = is_fatafat_top_job;
    }

    private int job_id;
    private boolean is_special_apply;
    private boolean is_fatafat_action;
    private boolean is_fatafat_top_job;
}
