package PojoJobseeker.PojoJDCall;

import PojoJobseeker.PojoGetJobs.ResponseGetJobs;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseJDCall {

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }


    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    private boolean status;
    private Data data;
    private String message;
    private int code;

    // Constructor, getters, and setters
}

class Data {
    @JsonProperty("call_allowed") // Map JSON field to Java field
    private boolean call_allowed;
    @JsonProperty("call_allowed_message") // Map JSON field to Java field
    private String call_allowed_message;
    private List<Option> options;
    private boolean is_audio_upload_allowed;
    private List<Object> questions;
    private boolean salary;
    private PostApplyCampaign post_apply_campaign;
    private boolean lead_qualification_form;
    private Config config;
    private boolean show_referral_banner;
    private boolean show_fraud_education;
    private String job_contact;
    private int UserJobApplyCount;

    // Constructor, getters, and setters
}

class Option {
    private int id;
    private String label;

    // Constructor, getters, and setters
}

class PostApplyCampaign {
    // Fields if any
}

class Config {
// Fields if any

}