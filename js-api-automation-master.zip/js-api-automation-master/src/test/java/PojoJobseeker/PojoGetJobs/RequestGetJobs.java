package PojoJobseeker.PojoGetJobs;

import java.util.List;
import java.util.Map;

public class RequestGetJobs {

    private int page;
    private int size;
    private String job_type;
    private Map<String, Object> filter;
    private Map<String, Object> title_filters;
    private Map<String, Object> distance_filters;
    private List<Object> contextual_filters;
    private Map<String, Object> bus_metro_filters;

    private Map<String, Object> keyword;
    private Map<String, Object> category;

    private Map<String, Object> city;
    private String locality;

    private boolean topMatchJobsOnly;

    private Map<String, Object> passed_filters;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getJob_type() {
        return job_type;
    }

    public void setJob_type(String job_type) {
        this.job_type = job_type;
    }

    public Map<String, Object> getFilter() {
        return filter;
    }

    public void setFilter(Map<String, Object> filter) {
        this.filter = filter;
    }

    public Map<String, Object> getTitle_filters() {
        return title_filters;
    }

    public void setTitle_filters(Map<String, Object> title_filters) {
        this.title_filters = title_filters;
    }

    public Map<String, Object> getDistance_filters() {
        return distance_filters;
    }

    public void setDistance_filters(Map<String, Object> distance_filters) {
        this.distance_filters = distance_filters;
    }

    public List<Object> getContextual_filters() {
        return contextual_filters;
    }

    public void setContextual_filters(List<Object> contextual_filters) {
        this.contextual_filters = contextual_filters;
    }

    public Map<String, Object> getBus_metro_filters() {
        return bus_metro_filters;
    }

    public void setBus_metro_filters(Map<String, Object> bus_metro_filters) {
        this.bus_metro_filters = bus_metro_filters;
    }

    public Map<String, Object> getKeyword() {
        return keyword;
    }

    public void setKeyword(Map<String, Object> keyword) {
        this.keyword = keyword;
    }

    public Map<String, Object> getCategory() {
        return category;
    }

    public void setCategory(Map<String, Object> category) {
        this.category = category;
    }

    public Map<String, Object> getCity() {
        return city;
    }

    public void setCity(Map<String, Object> city) {
        this.city = city;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public boolean isTopMatchJobsOnly() {
        return topMatchJobsOnly;
    }

    public void setTopMatchJobsOnly(boolean topMatchJobsOnly) {
        this.topMatchJobsOnly = topMatchJobsOnly;
    }

    public Map<String, Object> getPassed_filters() {
        return passed_filters;
    }

    public void setPassed_filters(Map<String, Object> passed_filters) {
        this.passed_filters = passed_filters;

    }
}






















