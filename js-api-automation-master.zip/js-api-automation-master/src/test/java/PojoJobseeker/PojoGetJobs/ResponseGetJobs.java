package PojoJobseeker.PojoGetJobs;

import java.util.List;

public class ResponseGetJobs {

    private boolean status;
    private JobDataWrapper data;

    // Getters and setters
    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public JobDataWrapper getData() {
        return data;
    }

    public void setData(JobDataWrapper data) {
        this.data = data;
    }

    public String getStatusCode() {


        return null;
    }

    class JobDataWrapper {
        private List<JobData> jobs;

        // Getters and setters
        public List<JobData> getJobs() {
            return jobs;
        }

        public void setJobs(List<JobData> jobs) {
            this.jobs = jobs;
        }
    }

    class JobData {
        private String interview_type;
        private int recommendations;
        private boolean is_manually_refreshed;
        private String job_locality_app_label;
        private int max_sal;
        private String max_exp;
        private String boost_score;
        private String job_title;
        private int min_sal;
        private String min_exp;
        private int views;
        private boolean is_new_job;
        private String job_distinction;
        private String job_locality_label;
        private String job_city_label;
        private int applies;
        private int job_id;
        private Location location;
        private String live_date;
        private int applications;
        private int score;
        private String salary_srp;
        private String posted_on;
        private String short_job_address;
        private Company company;
        private int id;
        private String srp_tuple_message;
        private boolean high_demand;
        private boolean active_hr;
        private boolean is_profile_matched;
        private String openings;
        private String distance;
        private boolean show_verified_tag;
        private boolean isDraft;
        private String job_post_time_elapsed;
        private String promoted_text;
        private boolean company_logo_variant;
        private Object brand_logo;

        // Getters and setters
        // Define getters and setters for all fields
    }

    class Location {
        private double lon;
        private double lat;

        // Getters and setters
        // Define getters and setters for lon and lat
    }

    class Company {
        private String company_name;
        private int company_id;
        private Object photo;

        // Getters and setters
        // Define getters and setters for company_name and company_id
    }

}















































