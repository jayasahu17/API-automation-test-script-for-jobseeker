package PojoJobseeker.PojoUserTask;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;


public class PojoUserTask {
    private boolean status;
    private Data data;
    private String message;
    private int code;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    class Data {
        @JsonProperty("welcomeText")
        private String welcomeText;
        @JsonProperty("descriptionText")
        private String descriptionText;
        @JsonProperty("taskData")
        private List<TaskData> taskData;

        public String getWelcomeText() {
            return welcomeText;
        }

        public void setWelcomeText(String welcomeText) {
            this.welcomeText = welcomeText;
        }

        public String getDescriptionText() {
            return descriptionText;
        }

        public void setDescriptionText(String descriptionText) {
            this.descriptionText = descriptionText;
        }

        public List<TaskData> getTaskData() {
            return taskData;
        }

        public void setTaskData(List<TaskData> taskData) {
            this.taskData = taskData;
        }
    }

    class TaskData {
        @JsonProperty("task_id")
        private String taskId;
        @JsonProperty("is_read")
        private boolean isRead;
        @JsonProperty("is_viewed")
        private boolean isViewed;
        private String type;
        @JsonProperty("header_h1")
        private String headerH1;
        @JsonProperty("header_h2")
        private String headerH2;
        private String cta;
        @JsonProperty("task_type")
        private String taskType;
        @JsonProperty("image_url")
        private String imageUrl;
        @JsonProperty("video_url")
        private String videoUrl;

        // Getters and setters
    }
}

















