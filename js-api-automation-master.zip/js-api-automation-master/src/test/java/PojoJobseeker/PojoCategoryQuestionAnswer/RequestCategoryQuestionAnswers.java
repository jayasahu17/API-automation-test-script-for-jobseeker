package PojoJobseeker.PojoCategoryQuestionAnswer;

public class RequestCategoryQuestionAnswers {

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }


    String category_id;


}
