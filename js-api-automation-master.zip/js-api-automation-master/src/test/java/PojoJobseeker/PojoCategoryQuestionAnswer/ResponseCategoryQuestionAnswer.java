package PojoJobseeker.PojoCategoryQuestionAnswer;


import java.util.List;
import java.util.Map;

public class ResponseCategoryQuestionAnswer {

        private boolean status;
        private Data data;
        private String message;
        private int code;

        public boolean isStatus() {
            return status;
        }

        public void setStatus(boolean status) {
            this.status = status;
        }

        public Data getData() {
            return data;
        }

        public void setData(Data data) {
            this.data = data;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public static class Data {
            private List<?> question_answers;
            private Map<String, Object> other_details;

            public List<?> getQuestion_answers() {
                return question_answers;
            }

            public void setQuestion_answers(List<?> question_answers) {
                this.question_answers = question_answers;
            }

            public Map<String, Object> getOther_details() {
                return other_details;
            }

            public void setOther_details(Map<String, Object> other_details) {
                this.other_details = other_details;
            }
        }
    }







