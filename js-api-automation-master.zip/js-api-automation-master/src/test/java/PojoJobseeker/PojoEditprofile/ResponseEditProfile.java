package PojoJobseeker.PojoEditprofile;

import com.fasterxml.jackson.databind.introspect.TypeResolutionContext;
import org.apache.commons.codec.language.bm.Languages;

public class ResponseEditProfile {

    public void getBASICS() {
        getBASICS();
    }

    public void setBASICS(TypeResolutionContext.Basic BASICS) {
        this.BASICS = BASICS;
    }

    public Languages getLANGUAGE() {
        return LANGUAGE;
    }

    public void setLANGUAGE(Languages LANGUAGE) {
        this.LANGUAGE = LANGUAGE;
    }

    private TypeResolutionContext.Basic BASICS;
    private Languages LANGUAGE;


    public boolean isStatus() {
        return isStatus();
    }
}