package PojoJobseeker.PojoEditprofile;

public class RequestBASIC {

    private boolean addReferCount;
    private String address;
    private int age;
    private String city_id;

    public void setCurrent_salary(int current_salary) {
        this.current_salary = current_salary;
    }

    private int current_salary;
    private String email;

    private String gender;

    private boolean is_sms_enabled;

    private boolean is_whatsapp_enabled;

    private boolean is_whatsapp_enabled_for_recruiter;

    private boolean is_whatsapp_permission_allowed;

    private String locality_id;

    private String name;

    private int qualification_id;
    private String school_medium;

    public boolean isAddReferCount() {
        return addReferCount;
    }

    public void setAddReferCount(boolean addReferCount) {
        this.addReferCount = addReferCount;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCity_id() {
        return city_id;
    }

    public void setCity_id(String city_id) {
        this.city_id = city_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isIs_sms_enabled() {
        return is_sms_enabled;
    }

    public void setIs_sms_enabled(boolean is_sms_enabled) {
        this.is_sms_enabled = is_sms_enabled;
    }

    public boolean isIs_whatsapp_enabled() {
        return is_whatsapp_enabled;
    }

    public void setIs_whatsapp_enabled(boolean is_whatsapp_enabled) {
        this.is_whatsapp_enabled = is_whatsapp_enabled;
    }

    public boolean isIs_whatsapp_enabled_for_recruiter() {
        return is_whatsapp_enabled_for_recruiter;
    }

    public void setIs_whatsapp_enabled_for_recruiter(boolean is_whatsapp_enabled_for_recruiter) {
        this.is_whatsapp_enabled_for_recruiter = is_whatsapp_enabled_for_recruiter;
    }

    public boolean isIs_whatsapp_permission_allowed() {
        return is_whatsapp_permission_allowed;
    }

    public void setIs_whatsapp_permission_allowed(boolean is_whatsapp_permission_allowed) {
        this.is_whatsapp_permission_allowed = is_whatsapp_permission_allowed;
    }

    public String getLocality_id() {
        return locality_id;
    }

    public void setLocality_id(String locality_id) {
        this.locality_id = locality_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQualification_id() {
        return qualification_id;
    }

    public void setQualification_id(int qualification_id) {
        this.qualification_id = qualification_id;
    }

    public String getSchool_medium() {
        return school_medium;
    }

    public void setSchool_medium(String school_medium) {
        this.school_medium = school_medium;
    }

    public String getSchool_subject() {
        return school_subject;
    }

    public void setSchool_subject(String school_subject) {
        this.school_subject = school_subject;
    }

    private String school_subject;
}





